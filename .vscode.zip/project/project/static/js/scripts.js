// scripts.js

$(document).ready(function() {
    // Example: Filter attendance records based on project name
    $('#projectFilter').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('#attendanceTable tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});
