from django.shortcuts import render, redirect
from .models import GroupProject, Attendance, Assignment, Task, Task_collections
from .forms import GroupProjectForm, AttendanceForm
from django.http import JsonResponse
from .models import Project, Submission
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import View
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import  Assignment, Task
from django.contrib.auth import get_user_model
# from userprofile.models import Profiles
from .models import Task_collections
from django.urls import reverse_lazy, reverse
import pdb
from .forms import TaskForm


# Existing views.
def dashboard_assignment(request):
    assignments = Assignment.objects.all()
    return render(request, 'dashboard/dashboard_assignment.html', {'assignments': assignments})

def dashboard_task(request):
    tasks = Task.objects.all()
    return render(request, 'dashboard/dashboard_task.html', {'tasks': tasks})

def dashboard_task_collections(request):
    task_collections = Task_collections.objects.all()
    return render(request, 'dashboard/dashboard_task_collections.html', {'task_collections': task_collections})





def home(request):
    return render(request, 'dashboard/home.html')  # Make sure you have a template named home.html

def submit_project(request):
    if request.method == 'POST':
        form = GroupProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.submitted_by = request.user
            project.save()
            return redirect('project_list')
    else:
        form = GroupProjectForm()
    return render(request, 'dashboard/submit_project.html', {'form': form})

def record_attendance(request):
    if request.method == 'POST':
        form = AttendanceForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('attendance_list')
    else:
        form = AttendanceForm()
    return render(request, 'dashboard/record_attendance.html', {'form': form})

def project_attendance_view(request):
    attendances = Attendance.objects.all()
    return render(request, 'dashboard/project_attendance_views.html', {'attendances': attendances })


# projects/views.py

def project_list(request):
    projects = Project.objects.all()
    return render(request, 'dashboard/project_list.html', {'project': projects})

@csrf_exempt  # Use only if you're testing; better to handle CSRF properly in production
def submit_project(request):
    if request.method == 'POST':
        project_id = request.POST.get('project_id')
        submission_text = request.POST.get('submission_text')
        project = Project.objects.get(id=project_id)
        
        if project.is_open_for_submission():
            submission = Submission(project=project, student=request.user)
            submission.save()
            return JsonResponse({'message': 'Submission successful'})
        else:
            return JsonResponse({'error': 'Submission period has ended'}, status=400)
    return JsonResponse({'error': 'Invalid request'}, status=400)
