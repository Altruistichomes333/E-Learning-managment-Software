

from django import forms
from .models import Cohort, GroupProject, Project, Submission, Assignment, Task, Task_collections, Attendance

class CohortForm(forms.ModelForm):
    class Meta:
        model = Cohort
        fields = ['name']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Cohort Name'}),
        }


class GroupProjectForm(forms.ModelForm):
    class Meta:
        model = GroupProject
        fields = ['title', 'cohorts', 'submitted_by']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Project Title'}),
            'cohort': forms.Select(attrs={'class': 'form-control'}),
            'submitted_by': forms.Select(attrs={'class': 'form-control'}),
        }


class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['title', 'description', 'instructor', 'start_time', 'end_time', 'second_chance_start', 'second_chance_end']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Project Title'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Project Description'}),
            'instructor': forms.Select(attrs={'class': 'form-control'}),
            'start_time': forms.DateTimeInput(attrs={'class': 'form-control', 'placeholder': 'Start Time'}),
            'end_time': forms.DateTimeInput(attrs={'class': 'form-control', 'placeholder': 'End Time'}),
            'second_chance_start': forms.DateTimeInput(attrs={'class': 'form-control', 'placeholder': 'Second Chance Start'}),
            'second_chance_end': forms.DateTimeInput(attrs={'class': 'form-control', 'placeholder': 'Second Chance End'}),
        }


class SubmissionForm(forms.ModelForm):
    class Meta:
        model = Submission
        fields = ['project', 'student']
        widgets = {
            'project': forms.Select(attrs={'class': 'form-control'}),
            'student': forms.Select(attrs={'class': 'form-control'}),
        }


class AssignmentForm(forms.ModelForm):
    class Meta:
        model = Assignment
        fields = ['git_hub', 'user', 'projects', 'cohorts', 'score_project', 'status', 'task_img',
                'links', 'task_description']
        widgets = {
            'git_hub': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'GitHub URL'}),
            'user': forms.Select(attrs={'class': 'form-control'}),
            'projects': forms.Select(attrs={'class': 'form-control'}),
            'cohorts': forms.Select(attrs={'class': 'form-control'}),
            'score_project': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Score'}),
            'status': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Status'}),
            'task_img': forms.ClearableFileInput(attrs={'class':  'form-control'}),
            'links': forms.URLInput(attrs={'class ': 'form-control', 'placeholder': 'links'}),
            'task_description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Task Description'}),

            # 'task_description': forms.Textarea(attrs=('class':'form-control', 'placeholder', 'Task_Description')),
            'file': forms.ClearableFileInput(attrs={'class': 'form- control'}),
        }
            


class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['student', 'task', 'status', 'task_img', 'links', 'task_description']
        widgets = {
            'student': forms.Select(attrs={'class': 'form-control'}),
            'task': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Task Name'}),
            'status': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Status'}),
            'task_img': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'links': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'Links'}),
            'task_description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Task Description'}),
        }


class TaskCollectionForm(forms.ModelForm):
    class Meta:
        model = Task_collections
        fields = ['student', 'task', 'status', 'screen_short', 'links']
        widgets = {
            'student': forms.Select(attrs={'class': 'form-control'}),
            'task': forms.Select(attrs={'class': 'form-control'}),
            'status': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Status'}),
            'screen_short': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'links': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'Links'}),
        }


class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['student', 'project']
        widgets = {
            'student': forms.Select(attrs={'class': 'form-control'}),
            'project': forms.Select(attrs={'class': 'form-control'}),
            'date': forms.DateInput(attrs={'class': 'form-control', 'placeholder': 'Date'}),
        }
