from django.urls import path
from .views import project_list, submit_project, record_attendance, project_attendance_view


urlpatterns = [
    # path('', submit_project, name='dashboard_submit_project'),
    path('submit/', submit_project, name='submit_project'),
    path('attendance',  record_attendance, name='record_attendance'),
    path('attendance/view/', project_attendance_view, name='attendance_list'),

    
]


# projects/urls.py


urlpatterns = [
    path('', project_list, name='project_list'),
    path('submit/', submit_project, name='submit_project'),
]
