from django.db import models

from django.utils import timezone
from .cohorts import Cohort




from django.contrib.auth.models import User  # Import User model
from django.conf import settings
from django.http import HttpResponse
# from ckeditor_uploader.fields import RichTextUploadingField




class GroupProject(models.Model):
    STATUS_CHOICES = (
        ('expired', 'Expired'),
        ('active', 'Active'),
        ('pending', 'Pending')
    )
    
    instructor = models.ForeignKey(User, on_delete=models.CASCADE)
    # Ensure these fields are defined
    cohorts = models.ManyToManyField(Cohort)  # Example field
    submitted_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='submitted_projects')

    group_name = models. CharField(max_length=50)
    group_members = models.ManyToManyField(User, related_name='group_members')
    date = models.DateTimeField(auto_now_add=True)
    Status = models.CharField(max_length=50, default='Not Submitted')
    Project = models.ForeignKey('project', on_delete=models.CASCADE, null=True, blank=True)
    
    
    title = models.CharField(max_length=255)
    # Other fields...





class Project(models.Model):
    STATUS_CHOICES = (
        ('expired', 'Expired'),
        ('active', 'Active'),
        ('pending', 'Pending')
    )
    
    title = models.CharField(max_length=200)
    cohorts = models.ForeignKey(Cohort, on_delete=models.CASCADE,  null=True, blank=True, related_name='projects')
    description = models.TextField(null=True, blank=True)
    instructor = models.ForeignKey(User, on_delete=models.CASCADE,  null=True, blank=True, related_name='projects')
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    second_chance_start = models.DateTimeField(null=True, blank=True)
    second_chance_end = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=50)
    # cohort_reference = models.ForeignKey('Cohort', on_delete=models.CASCADE, null=True, blank=True, related_name='projects')
    project_img = models.ImageField(upload_to='project_image', blank=True, null=True)
    project_link = models.URLField(blank=True, null=True)
    

    def is_open_for_submission(self):
        now = timezone.now()
        return self.start_time <= now <= self.end_time or (self.second_chance_start and self.second_chance_start <= now <= self.second_chance_end)

    def __str__(self):
        return self.title

class Submission(models.Model):
    TASK_STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('complete', 'Complete')
    )
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    submitted_at = models.DateTimeField(auto_now_add=True)
    cohorts_id = models.ForeignKey('Cohort', on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=50)   
    class Meta:
        unique_together = ('project', 'student')

    def __str__(self):
        return f"{self.student.username} - {self.project.title}"







class Assignment(models.Model):
    ASSIGNMENT_STATUS_CHOICES = (
        ('reviewing', 'Reviewing'),
        ('complete', 'Complete'),
        ('reject', 'Reject')
    )
    # file = models.FileField(upload_to='assignments/', blank=True, null=True)

    
    git_hub = models.URLField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    projects = models.ForeignKey(Project, on_delete=models.CASCADE)
    cohorts = models.ForeignKey(Cohort, on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)
    score_project = models.FloatField(null=True, blank=True)
    file = models.FileField(upload_to='assignments/', default='assignments/default.txt')




    task_img = models.ImageField(upload_to='taskimage')
    links = models.URLField(null=True, blank=True)
    task_description = models.TextField( null=True, blank=True)
    task_status = (
        ('pending', 'Pending'),
        ('complete', 'Complete')
    )
    status = models.CharField(choices=task_status, default='pending', max_length=200)
    file = models.FileField(upload_to='assignments/') 

    def score_calculations(self):
        # scores = self.user.assignments.aggregate(total_score=models.Sum('score_project'))['total_score']
        return scores

    def __str__(self):
        return f"Assignment for {self.user.username} in {self.projects.title}"


class Task(models.Model):
    TASK_STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('complete', 'Complete')
    )
    
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    task = models.CharField(max_length=200)
    status = models.CharField(max_length=50)
    task_img = models.ImageField(upload_to='task_images/', null=True, blank=True)
    links = models.URLField(null=True, blank=True)
    task_description = models.TextField()
    
    title = models.CharField(max_length=100)
    project = models.ForeignKey(Project, related_name='tasks', on_delete=models.CASCADE)
    cohorts = models.ForeignKey(Cohort, related_name='tasks', on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    passcode = models.CharField(max_length=10)


    def __str__(self):
        return self.task


class Task_collections(models.Model):
    TASK_STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('complete', 'Complete')
    )
    
    student = models.ForeignKey(User, on_delete=models.CASCADE,  null=True, blank=True, related_name='Task_collections')
    task = models.ForeignKey(Task, on_delete=models.CASCADE,  null=True, blank=True, related_name='projects')
    status = models.CharField(max_length=50)
    screen_short = models.ImageField(upload_to='screenshots/', null=True, blank=True)
    links = models.URLField(null=True, blank=True)
    links2 = models.URLField(blank=True)
    links3 = models.URLField(blank=True)

    def __str__(self):
        return f"Task Collections for {self.student.username}"

class Student(models.Model):
    # fields for Student
    name = models.CharField(max_length=100)
    # ... any other fields



class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    status = models.CharField(max_length=10)
    date = models.DateField(auto_now_add=True)  # <- this line

    
    
    
    
    def __str__(self):
        return f"Attendance for {self.student.username} in {self.project.title} on {self.date}"



    
class TimezoneField(models.DateTimeField):
    def __init__(self, *args, **kwargs):
        self.timezone = kwargs.pop('timezone', None)
        super().__init__(*args, **kwargs)
        
