from django.contrib import admin
from .models import GroupProject, Project, Submission, Assignment, Task, Task_collections, Attendance, Cohort

@admin.register(GroupProject)
class GroupProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'group_name', 'instructor', 'date', 'Status')
    list_filter = ('Status', 'date')
    search_fields = ('title', 'group_name', 'instructor__username')
    filter_horizontal = ('group_members', 'cohorts')  # ManyToMany fields

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'cohorts', 'instructor', 'start_time', 'end_time', 'status')
    list_filter = ('status', 'start_time', 'end_time')
    search_fields = ('title', 'description')
    date_hierarchy = 'start_time'
    ordering = ('-start_time',)

@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display = ('project', 'student', 'submitted_at', 'status')
    list_filter = ('status', 'submitted_at')
    search_fields = ('student__username', 'project__title')

@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display = ('user', 'projects', 'cohorts', 'date', 'score_project','task_img',
                    'links', 'status', 'file', 'task_description', 'task_status')
    list_filter = ('status', 'date')
    search_fields = ('user__username', 'projects__title')

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('student', 'task', 'status')
    list_filter = ('status',)
    search_fields = ('student__username', 'task')

@admin.register(Task_collections)
class TaskCollectionsAdmin(admin.ModelAdmin):
    list_display = ('student', 'task', 'status')
    list_filter = ('status',)
    search_fields = ('student__username', 'task__task')

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('student', 'project', 'date', 'status')
    list_filter =  ('status', 'date')
    search_fields = ('student__username', 'project__title')
    
    @admin.register(Cohort)
    class CohortsAdmin(admin.ModelAdmin):
        list_display = ('name', 'list_display', 'start_date')
        list_filter = ('start_date',)
        search_fields = ('name',)
        date_hierarchy = 'start_date'
        ordering = ('-start_date',)



